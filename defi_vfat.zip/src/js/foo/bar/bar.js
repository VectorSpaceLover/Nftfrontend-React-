console.log('this is bar.js')

export default function() {
  console.log('bar logging function')
}

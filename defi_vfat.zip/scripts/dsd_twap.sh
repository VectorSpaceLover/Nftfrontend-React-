pushd /opt/vfat-tools
node /home/vfatouros/scripts/twap.js 0x66e33d2605c5fb25ebb7cd7528e7997b0afa55e8
popd
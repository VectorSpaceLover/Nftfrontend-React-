pushd /opt/vfat-tools
node /home/vfatouros/scripts/twap.js 0x88ff79eB2Bc5850F27315415da8685282C7610F9
popd